#!/bin/bash
./build/vehicle_detection_haarcascades cars.xml dataset/video1.avi
